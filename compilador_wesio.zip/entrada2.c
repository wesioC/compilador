int main() {
    int contador_1 = 2;
    contador_1 = 5 + (4 - contador_1) * (5 - 1);
    return contador_1;
}